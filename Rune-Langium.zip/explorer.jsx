// Explorer panel — namespace tree with kind chips + filter pills
const KIND_META = {
  data:   { color:'#00D4AA', label:'data',   glyph:'D' },
  choice: { color:'#E8913A', label:'choice', glyph:'C' },
  enum:   { color:'#8B7BF4', label:'enum',   glyph:'E' },
  func:   { color:'#82AAFF', label:'func',   glyph:'F' },
};

const Explorer = ({ focusType, onSelect }) => {
  const [filters, setFilters] = React.useState({ data:true, choice:true, enum:true, func:true });
  const [open, setOpen] = React.useState({ product:true, event:false, party:false, asset:false, rate:false });
  const [q, setQ] = React.useState('');
  const toggleFilter = (k) => setFilters(f => ({ ...f, [k]: !f[k] }));

  return (
    <div className="rs-explorer">
      <div className="rs-panel-hd">
        <div className="rs-panel-title">
          {I.files}<span>Workspace</span>
          <span className="rs-panel-sub">· 73 types</span>
        </div>
        <div className="rs-panel-actions">
          <button className="rs-icon-btn" aria-label="New">{I.plus}</button>
          <button className="rs-icon-btn" aria-label="More">{I.more}</button>
        </div>
      </div>
      <div className="rs-search">
        {I.search}
        <input value={q} onChange={e => setQ(e.target.value)} placeholder="Filter types…"/>
        {q ? <button className="rs-icon-btn" onClick={() => setQ('')}>{I.x}</button> :
             <kbd>/</kbd>}
      </div>
      <div className="rs-pills">
        {Object.entries(KIND_META).map(([k,m]) => (
          <button key={k} className={`rs-pill ${filters[k]?'is-on':''}`}
                  style={filters[k] ? { color:m.color, borderColor:`color-mix(in oklch, ${m.color}, transparent 65%)` } : null}
                  onClick={() => toggleFilter(k)}>
            <span className="rs-pill-dot" style={{background:m.color}}/>
            {m.label}
          </button>
        ))}
      </div>
      <div className="rs-tree">
        {window.RUNE_DATA.NAMESPACES.map(ns => {
          const isOpen = open[ns.id];
          const visTypes = ns.types.filter(t => filters[t.kind] &&
            (!q || t.id.toLowerCase().includes(q.toLowerCase())));
          return (
            <div key={ns.id}>
              <button className="rs-ns-row" onClick={() => setOpen(o => ({ ...o, [ns.id]: !o[ns.id] }))}>
                {isOpen ? I.chevD : I.chevR}
                <span className="rs-ns-name">{ns.name}</span>
                <span className="rs-ns-count">{Object.values(ns.counts).reduce((a,b)=>a+b,0)}</span>
              </button>
              {isOpen && (
                <div className="rs-ns-body">
                  <div className="rs-ns-kinds">
                    {Object.entries(ns.counts).filter(([,n]) => n > 0).map(([k,n]) => {
                      const m = KIND_META[k];
                      return (
                        <span key={k} className="rs-kind-chip"
                              style={{
                                color:m.color,
                                background:`color-mix(in oklch, ${m.color}, transparent 88%)`,
                                border:`0.5px solid color-mix(in oklch, ${m.color}, transparent 70%)`,
                              }}>
                          <span className="rs-kind-chip-dot" style={{background:m.color}}/>
                          <span className="rs-kind-chip-num">{n}</span>
                          <span>{m.label}</span>
                        </span>
                      );
                    })}
                  </div>
                  <div className="rs-ns-types">
                    {visTypes.map(t => {
                      const m = KIND_META[t.kind];
                      const isFocus = focusType === t.id;
                      return (
                        <button key={t.id} className={`rs-type-row ${isFocus?'is-focus':''}`}
                                onClick={() => onSelect?.(t)}>
                          {isFocus && <span className="rs-type-active-pip"/>}
                          <span className="rs-type-glyph"
                                style={{
                                  color:m.color,
                                  background:`color-mix(in oklch, ${m.color}, transparent 84%)`,
                                  borderColor:`color-mix(in oklch, ${m.color}, transparent 65%)`,
                                }}>{m.glyph}</span>
                          <span className="rs-type-name">{t.id}</span>
                          <span className="rs-ns-count">{t.refs}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

window.Explorer = Explorer;
window.KIND_META = KIND_META;
