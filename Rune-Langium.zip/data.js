// Rune Studio — sample data (CDM-flavored: namespaces, types, members, diagnostics)
window.RUNE_DATA = {
  TABS: [
    { id:'tradable',  name:'cdm/product/template/TradableProduct.rosetta', dirty:true,  errors:1, warnings:2 },
    { id:'economic',  name:'cdm/product/template/EconomicTerms.rosetta',   dirty:false, errors:0, warnings:1 },
    { id:'event',     name:'cdm/event/common/TradeState.rosetta',          dirty:false, errors:0, warnings:0 },
    { id:'party',     name:'cdm/base/staticdata/party/Party.rosetta',      dirty:false, errors:0, warnings:0 },
  ],

  // Type kinds (mapped to CDM design-system colors)
  KINDS: {
    data:   { color:'#00D4AA', label:'data',   glyph:'D' },
    choice: { color:'#E8913A', label:'choice', glyph:'C' },
    enum:   { color:'#8B7BF4', label:'enum',   glyph:'E' },
    func:   { color:'#82AAFF', label:'func',   glyph:'F' },
  },

  NAMESPACES: [
    { id:'product', name:'cdm.product.template', counts:{ data:14, choice:2, enum:1, func:3 }, expanded:true,
      types: [
        { id:'TradableProduct',     kind:'data',   members:6, refs:8 },
        { id:'EconomicTerms',       kind:'data',   members:9, refs:12 },
        { id:'Product',             kind:'choice', members:4, refs:5 },
        { id:'PriceQuantity',       kind:'data',   members:3, refs:14 },
        { id:'NotionalAdjustment',  kind:'enum',   members:3, refs:2 },
      ]
    },
    { id:'event', name:'cdm.event.common', counts:{ data:11, choice:1, enum:2, func:5 }, expanded:false,
      types: [
        { id:'TradeState',          kind:'data',   members:5, refs:18 },
        { id:'BusinessEvent',       kind:'data',   members:7, refs:22 },
      ]
    },
    { id:'party', name:'cdm.base.staticdata.party', counts:{ data:8, choice:0, enum:3, func:2 }, expanded:false,
      types: [
        { id:'Party',               kind:'data',   members:4, refs:34 },
        { id:'PartyRole',           kind:'enum',   members:18, refs:9 },
      ]
    },
    { id:'asset', name:'cdm.product.asset', counts:{ data:22, choice:3, enum:4, func:6 }, expanded:false, types:[] },
    { id:'rate',  name:'cdm.product.rate',  counts:{ data:18, choice:1, enum:2, func:8 }, expanded:false, types:[] },
  ],

  // Graph nodes (DAG layout)
  GRAPH_NODES: [
    { id:'TradableProduct', name:'TradableProduct', kind:'data', x:520, y:180, ns:'cdm.product.template', card:'1..1',
      members:[
        { name:'product',           type:'NonTransferableProduct', kind:'data',   card:'1..1' },
        { name:'tradeLot',          type:'TradeLot',               kind:'data',   card:'1..*' },
        { name:'counterparty',      type:'Counterparty',           kind:'data',   card:'2..2' },
        { name:'ancillaryParty',    type:'AncillaryParty',         kind:'data',   card:'0..*' },
        { name:'adjustment',        type:'NotionalAdjustment',     kind:'enum',   card:'0..1' },
      ] },
    { id:'NonTransferableProduct', name:'NonTransferableProduct', kind:'data', x:240, y:90,  ns:'cdm.product.template', card:'1..1' },
    { id:'EconomicTerms', name:'EconomicTerms', kind:'data', x:240, y:240, ns:'cdm.product.template', card:'1..1',
      members:[
        { name:'effectiveDate', type:'AdjustableDate', kind:'data', card:'0..1' },
        { name:'payout',        type:'Payout',         kind:'choice', card:'1..1' },
      ] },
    { id:'Counterparty',   name:'Counterparty',   kind:'data',   x:240, y:380, ns:'cdm.event.common',  card:'1..1' },
    { id:'TradeLot',       name:'TradeLot',       kind:'data',   x:830, y:90,  ns:'cdm.product.template', card:'1..*' },
    { id:'PriceQuantity',  name:'PriceQuantity',  kind:'data',   x:830, y:220, ns:'cdm.product.template', card:'1..*' },
    { id:'NotionalAdjustment', name:'NotionalAdjustment', kind:'enum', x:830, y:340, ns:'cdm.product.template', card:'0..1' },
    { id:'Payout',         name:'Payout',         kind:'choice', x:1100, y:130, ns:'cdm.product.common',   card:'1..1' },
    { id:'Party',          name:'Party',          kind:'data',   x:1100, y:280, ns:'cdm.base.staticdata.party', card:'1..1' },
  ],

  GRAPH_EDGES: [
    { from:'NonTransferableProduct', to:'TradableProduct', kind:'data',   ext:false },
    { from:'EconomicTerms',          to:'TradableProduct', kind:'data',   ext:false },
    { from:'Counterparty',           to:'TradableProduct', kind:'data',   ext:true  },
    { from:'TradableProduct',        to:'TradeLot',        kind:'data',   ext:false },
    { from:'TradableProduct',        to:'PriceQuantity',   kind:'data',   ext:false },
    { from:'TradableProduct',        to:'NotionalAdjustment', kind:'enum',ext:false },
    { from:'TradeLot',               to:'Payout',          kind:'choice', ext:false },
    { from:'PriceQuantity',          to:'Party',           kind:'data',   ext:true  },
  ],

  PROBLEMS: [
    { sev:'error', msg:'Type \'AncillaryParty\' is referenced but not defined in scope', file:'TradableProduct.rosetta', line:42, col:18 },
    { sev:'warning', msg:'Cardinality \'0..*\' on `adjustment` may produce empty arrays in TS output', file:'TradableProduct.rosetta', line:67, col:9 },
    { sev:'warning', msg:'Unused import: `cdm.base.math.UnitType`', file:'TradableProduct.rosetta', line:6, col:1 },
    { sev:'warning', msg:'Function `currentNotional` has no return condition', file:'EconomicTerms.rosetta', line:128, col:3 },
  ],

  ACTIVITY: [
    { time:'12:04:18', tag:'lsp',  ok:true,  msg:'didChange · TradableProduct.rosetta · 412 bytes · 38ms' },
    { time:'12:04:17', tag:'gen',  ok:true,  msg:'TypeScript codegen · 14 files · 92ms' },
    { time:'12:04:11', tag:'val',  ok:false, msg:'Validation · 1 error, 2 warnings' },
    { time:'12:04:09', tag:'lsp',  ok:true,  msg:'publishDiagnostics · 3 entries' },
    { time:'12:03:57', tag:'git',  ok:true,  msg:'fetch origin/master · 2 commits behind' },
    { time:'12:03:42', tag:'opfs', ok:true,  msg:'snapshot saved · workspace cdm-7.0.0-dev.83' },
  ],
};
