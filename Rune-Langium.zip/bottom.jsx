// Bottom panel — Problems / Activity / Output tabs
const Bottom = () => {
  const [tab, setTab] = React.useState('problems');
  const probs = window.RUNE_DATA.PROBLEMS;
  const errs = probs.filter(p => p.sev==='error').length;
  const warns = probs.filter(p => p.sev==='warning').length;

  return (
    <div className="rs-bottom">
      <div className="rs-bottom-hd">
        <div className="rs-bottom-tabs">
          <button className={tab==='problems'?'is-on':''} onClick={() => setTab('problems')}>
            Problems
            <span className="rs-tab-bad rs-bad-err"><span className="rs-bad-err-dot"/>{errs}</span>
            <span className="rs-tab-bad rs-bad-warn"><span className="rs-bad-warn-dot"/>{warns}</span>
          </button>
          <button className={tab==='activity'?'is-on':''} onClick={() => setTab('activity')}>Activity</button>
          <button className={tab==='output'?'is-on':''} onClick={() => setTab('output')}>Output</button>
          <button className={tab==='terminal'?'is-on':''} onClick={() => setTab('terminal')}>Terminal</button>
        </div>
        <div className="rs-panel-actions">
          <button className="rs-icon-btn" aria-label="Filter">{I.filter}</button>
          <button className="rs-icon-btn" aria-label="More">{I.more}</button>
        </div>
      </div>
      <div className="rs-bottom-body">
        {tab === 'problems' && (
          <div className="rs-problems">
            {probs.map((p,i) => (
              <div key={i} className={`rs-prob ${p.sev==='error'?'rs-prob-err':'rs-prob-warn'}`}>
                {p.sev==='error' ? I.err : I.warn}
                <span className="rs-prob-msg">{p.msg}</span>
                <span className="rs-prob-loc">{p.file}<span> · {p.line}:{p.col}</span></span>
              </div>
            ))}
          </div>
        )}
        {tab === 'activity' && (
          <div className="rs-activity">
            {window.RUNE_DATA.ACTIVITY.map((a,i) => (
              <div key={i} className="rs-act-row">
                <span className="rs-act-time">{a.time}</span>
                <span className={`rs-act-tag ${a.ok?'rs-act-ok':'rs-act-bad'}`}>{a.tag}</span>
                <span>{a.msg}</span>
              </div>
            ))}
          </div>
        )}
        {tab === 'output' && (
          <div className="rs-out">
            <div className="rs-out-dim">[lsp] connected to ws://localhost:3001 · session 7f3e</div>
            <div className="rs-out-dim">[lsp] handshake complete · 218ms</div>
            <div>Compiling cdm.product.template…</div>
            <div className="rs-out-ok">  ✓ TradableProduct (6 members)</div>
            <div className="rs-out-ok">  ✓ EconomicTerms (9 members)</div>
            <div className="rs-out-ok">  ✓ PriceQuantity (3 members)</div>
            <div style={{color:'var(--rs-warn)'}}>  ⚠ adjustment cardinality 0..* · TS arrays may be empty</div>
            <div style={{color:'var(--rs-err)'}}>  ✗ AncillaryParty: undefined reference</div>
            <div className="rs-out-dim">Done · 1 error, 2 warnings · 92ms</div>
          </div>
        )}
        {tab === 'terminal' && (
          <div className="rs-out">
            <div><span className="rs-out-prompt">›</span>pnpm --filter @rune-langium/studio test</div>
            <div className="rs-out-dim"> RUN  v3.0.5</div>
            <div className="rs-out-ok"> ✓ test/components/SourceEditor.test.tsx (8)</div>
            <div className="rs-out-ok"> ✓ test/services/lsp-client.test.ts (12)</div>
            <div className="rs-out-ok"> ✓ test/services/diagnostics-bridge.test.ts (9)</div>
            <div> Test Files  13 passed (13)</div>
            <div>      Tests  94 passed (94)</div>
            <div className="rs-out-dim">   Duration  4.18s</div>
            <div><span className="rs-out-prompt">›</span><span className="rs-out-cursor"/></div>
          </div>
        )}
      </div>
    </div>
  );
};

window.Bottom = Bottom;
