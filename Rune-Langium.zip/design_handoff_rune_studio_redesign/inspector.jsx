// Inspector — STRUCTURAL editor for the selected type.
// Matches apps/studio's RuneObjectInspectorPanel: edits the type *definition*
// (members, cardinalities, references, conditions, doc) — not an instance.
// (Form preview lives in its own panel.)
const Inspector = ({ selectedNode }) => {
  const node = selectedNode || window.RUNE_DATA.GRAPH_NODES[0];
  const km = window.RUNE_DATA.KINDS[node.kind] || window.RUNE_DATA.KINDS.data;
  const [tab, setTab] = React.useState('members');

  // Editable structural members
  const seed = node.members || [
    { name:'product',         type:'NonTransferableProduct', kind:'data',   card:'1..1' },
    { name:'tradeLot',        type:'TradeLot',               kind:'data',   card:'1..*' },
    { name:'counterparty',    type:'Counterparty',           kind:'data',   card:'2..2' },
    { name:'ancillaryParty',  type:'AncillaryParty',         kind:'data',   card:'0..*' },
    { name:'adjustment',      type:'NotionalAdjustment',     kind:'enum',   card:'0..1' },
  ];
  const [members, setMembers] = React.useState(seed);
  const [doc, setDoc] = React.useState(
    'A product that may be traded between counterparties, including the non-transferable product definition, trade lot details, and party roles.');
  const [conds, setConds] = React.useState([
    { name:'PriceQuantityResolution', body:'if count(tradeLot) > 0 then tradeLot -> priceQuantity exists' },
  ]);

  const lastId = React.useRef(node.id);
  React.useEffect(() => {
    if (lastId.current !== node.id) {
      lastId.current = node.id;
      setMembers(node.members || seed);
    }
  }, [node.id]);

  const updateMember = (i, patch) =>
    setMembers(ms => ms.map((m, idx) => idx === i ? { ...m, ...patch } : m));
  const removeMember = (i) => setMembers(ms => ms.filter((_, idx) => idx !== i));
  const addMember = () => setMembers(ms => [...ms, { name:'newAttribute', type:'string', kind:'data', card:'0..1' }]);

  const KIND_OPTS = ['data','choice','enum','func'];
  const CARD_OPTS = ['1..1','0..1','1..*','0..*','2..2'];

  return (
    <div className="rs-panel">
      <div className="rs-panel-hd">
        <div className="rs-panel-title">
          <span className="rs-insp-glyph"
                style={{
                  color: km.color,
                  background: `color-mix(in oklch, ${km.color}, transparent 84%)`,
                  borderColor: `color-mix(in oklch, ${km.color}, transparent 60%)`,
                }}>{km.glyph}</span>
          <span style={{fontSize:13}}>{node.name}</span>
          <span className="rs-panel-sub">· definition</span>
        </div>
        <div className="rs-panel-actions">
          <button className="rs-icon-btn" aria-label="Open in graph" title="Reveal in graph"><Ic><path d="M9 3H3v6M21 9V3h-6M3 15v6h6M15 21h6v-6"/></Ic></button>
          <button className="rs-icon-btn" aria-label="More">{I.more}</button>
        </div>
      </div>

      <div className="rs-insp-tabs">
        {[['members','Members'],['conds','Conditions'],['doc','Doc'],['meta','Meta']].map(([id,lbl]) => (
          <button key={id} className={tab===id?'is-on':''} onClick={() => setTab(id)}>{lbl}</button>
        ))}
      </div>

      <div className="rs-insp-body">
        {tab === 'members' && (
          <div className="rs-form">
            <div className="rs-insp-name">
              <label className="rs-insp-lbl">Type name</label>
              <input className="rs-field-input" defaultValue={node.name}
                     style={{marginTop:0,fontSize:13}}/>
              <div className="rs-insp-namerow">
                <span className="rs-pill rs-pill-soft">{km.label}</span>
                <span className="rs-pill rs-pill-soft">{node.ns}</span>
              </div>
            </div>

            <div className="rs-insp-sect">
              <span>Attributes</span>
              <span className="rs-insp-sect-meta">{members.length}</span>
            </div>

            {members.map((m, i) => {
              const mk = window.RUNE_DATA.KINDS[m.kind] || window.RUNE_DATA.KINDS.data;
              return (
                <div key={i} className="rs-field rs-attr" data-noncommentable="">
                  <div className="rs-attr-row1">
                    <input className="rs-attr-name" value={m.name}
                           onChange={e => updateMember(i, { name: e.target.value })}/>
                    <button className="rs-icon-btn rs-attr-rm" onClick={() => removeMember(i)}
                            aria-label="Remove attribute">{I.x}</button>
                  </div>
                  <div className="rs-attr-row2">
                    <span className="rs-field-type-glyph"
                          style={{ color:mk.color,
                                   background:`color-mix(in oklch, ${mk.color}, transparent 82%)` }}>{mk.glyph}</span>
                    <select className="rs-attr-kind" value={m.kind}
                            onChange={e => updateMember(i, { kind: e.target.value })}>
                      {KIND_OPTS.map(k => <option key={k} value={k}>{k}</option>)}
                    </select>
                    <input className="rs-attr-type" value={m.type}
                           onChange={e => updateMember(i, { type: e.target.value })}/>
                    <select className="rs-attr-card" value={m.card}
                            onChange={e => updateMember(i, { card: e.target.value })}>
                      {CARD_OPTS.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                  </div>
                </div>
              );
            })}

            <button className="rs-pill rs-pill-dashed" onClick={addMember}>
              {I.plus}<span>add attribute</span>
            </button>
          </div>
        )}

        {tab === 'conds' && (
          <div className="rs-form">
            <div className="rs-insp-sect">
              <span>Conditions</span>
              <span className="rs-insp-sect-meta">{conds.length}</span>
            </div>
            {conds.map((c, i) => (
              <div key={i} className="rs-field rs-cond" data-noncommentable="">
                <div className="rs-attr-row1">
                  <input className="rs-attr-name" value={c.name}
                         onChange={e => setConds(cs => cs.map((x,idx) => idx===i ? {...x, name:e.target.value} : x))}/>
                  <button className="rs-icon-btn rs-attr-rm"
                          onClick={() => setConds(cs => cs.filter((_,idx)=>idx!==i))}
                          aria-label="Remove">{I.x}</button>
                </div>
                <textarea className="rs-cond-body" value={c.body}
                          onChange={e => setConds(cs => cs.map((x,idx) => idx===i ? {...x, body:e.target.value} : x))}/>
              </div>
            ))}
            <button className="rs-pill rs-pill-dashed"
                    onClick={() => setConds(cs => [...cs, { name:'NewCondition', body:'if … then …' }])}>
              {I.plus}<span>add condition</span>
            </button>
          </div>
        )}

        {tab === 'doc' && (
          <div className="rs-form">
            <div className="rs-insp-sect"><span>Documentation</span></div>
            <textarea className="rs-doc-edit" value={doc}
                      onChange={e => setDoc(e.target.value)}/>
            <p style={{color:'var(--rs-fg-3)',fontSize:11.5,margin:0}}>
              Rendered as <code style={{fontFamily:'var(--rs-font-mono)',fontSize:11}}>///</code> doc-comments above the type in <code style={{fontFamily:'var(--rs-font-mono)',fontSize:11}}>.rosetta</code> source. Markdown supported.
            </p>
          </div>
        )}

        {tab === 'meta' && (
          <div className="rs-doc">
            <div className="rs-doc-meta">
              <div><span>namespace</span><b>{node.ns}</b></div>
              <div><span>kind</span><b>{km.label}</b></div>
              <div><span>cardinality</span><b>{node.card}</b></div>
              <div><span>members</span><b>{members.length}</b></div>
              <div><span>references</span><b>14 downstream</b></div>
              <div><span>since</span><b>cdm-6.4.0</b></div>
            </div>
            <div className="rs-insp-sect" style={{marginTop:8}}><span>Annotations</span></div>
            <div style={{display:'flex',flexWrap:'wrap',gap:4}}>
              <span className="rs-pill rs-pill-soft">@RosettaDataType</span>
              <span className="rs-pill rs-pill-soft">@RootType</span>
              <span className="rs-pill rs-pill-soft">@Synonym(FpML)</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

window.Inspector = Inspector;
