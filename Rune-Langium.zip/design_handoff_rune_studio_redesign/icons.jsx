// Hairline 16px icons for Rune Studio
const Ic = ({ d, size = 16, sw = 1.4, fill, style, children }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill || 'none'}
       stroke="currentColor" strokeWidth={sw} strokeLinecap="round"
       strokeLinejoin="round" style={style}>
    {children || <path d={d}/>}
  </svg>
);

const RuneMark = ({ size = 22 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 3 L4 7.5 V16.5 L12 21 L20 16.5 V7.5 Z" stroke="currentColor" strokeWidth="1.2" opacity="0.55"/>
    <path d="M12 3 V21 M4 7.5 L20 16.5 M20 7.5 L4 16.5" stroke="currentColor" strokeWidth="1.2" opacity="0.45"/>
    <circle cx="12" cy="12" r="2.6" fill="currentColor"/>
  </svg>
);

const I = {
  search:    <Ic><circle cx="11" cy="11" r="6"/><path d="m20 20-4.3-4.3"/></Ic>,
  files:     <Ic><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8l-5-5zM14 3v5h5"/></Ic>,
  graph:     <Ic><circle cx="6" cy="6" r="2.2"/><circle cx="18" cy="6" r="2.2"/><circle cx="6" cy="18" r="2.2"/><circle cx="18" cy="18" r="2.2"/><path d="M8 6h8M6 8v8M18 8v8M8 18h8"/></Ic>,
  models:    <Ic><path d="M12 3 3 8l9 5 9-5-9-5zM3 13l9 5 9-5M3 18l9 5 9-5"/></Ic>,
  bell:      <Ic><path d="M6 8a6 6 0 1 1 12 0c0 7 3 9 3 9H3s3-2 3-9M9 21a3 3 0 0 0 6 0"/></Ic>,
  gear:      <Ic><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></Ic>,
  play:      <Ic><path d="M7 5l12 7-12 7V5z"/></Ic>,
  stop:      <Ic><rect x="6" y="6" width="12" height="12" rx="2"/></Ic>,
  plus:      <Ic><path d="M12 5v14M5 12h14"/></Ic>,
  minus:     <Ic><path d="M5 12h14"/></Ic>,
  fit:       <Ic><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></Ic>,
  x:         <Ic><path d="M6 6l12 12M6 18L18 6"/></Ic>,
  chevR:     <Ic><path d="M9 6l6 6-6 6"/></Ic>,
  chevD:     <Ic><path d="M6 9l6 6 6-6"/></Ic>,
  ghub:      <Ic><path d="M9 19c-4 1.5-4-2-6-2.5M15 22v-3.9a3.4 3.4 0 0 0-.9-2.6c3-.3 6.2-1.5 6.2-6.6A5.1 5.1 0 0 0 18.9 5a4.7 4.7 0 0 0-.1-3.5s-1.1-.4-3.8 1.4a13 13 0 0 0-7 0C5.3 1.1 4.2 1.5 4.2 1.5a4.7 4.7 0 0 0-.1 3.5 5.1 5.1 0 0 0-1.4 3.4c0 5.1 3.1 6.3 6.1 6.6a3.4 3.4 0 0 0-1 2.6V22"/></Ic>,
  share:     <Ic><circle cx="18" cy="5" r="2.5"/><circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="19" r="2.5"/><path d="M8 11l8-5M8 13l8 5"/></Ic>,
  err:       <Ic><circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16.5v.1"/></Ic>,
  warn:      <Ic><path d="M12 3 2 21h20zM12 10v5M12 18v.1"/></Ic>,
  more:      <Ic><circle cx="5" cy="12" r="1.4" fill="currentColor"/><circle cx="12" cy="12" r="1.4" fill="currentColor"/><circle cx="19" cy="12" r="1.4" fill="currentColor"/></Ic>,
  filter:    <Ic><path d="M4 5h16l-6 8v6l-4-2v-4z"/></Ic>,
  branch:    <Ic><circle cx="6" cy="5" r="2"/><circle cx="6" cy="19" r="2"/><circle cx="18" cy="12" r="2"/><path d="M6 7v10M8 5c4 0 8 3 8 7"/></Ic>,
  download:  <Ic><path d="M12 4v12M6 12l6 6 6-6M4 21h16"/></Ic>,
  bolt:      <Ic><path d="M13 2 4 14h7l-1 8 9-12h-7l1-8z"/></Ic>,
  enter:     <Ic><path d="M9 10h11v6M20 10l-4-4M20 10l-4 4M9 14l-4 4 4 4"/></Ic>,
  eye:       <Ic><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></Ic>,
};

window.Ic = Ic;
window.I = I;
window.RuneMark = RuneMark;
