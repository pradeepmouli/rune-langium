// Graph panel — CDM type DAG (interactive: pan, zoom, drag, select)
const GraphPanel = ({ accent, runState, onSelectNode, focusedNode }) => {
  const [nodes, setNodes] = React.useState(window.RUNE_DATA.GRAPH_NODES);
  const [selected, setSelected] = React.useState('TradableProduct');
  const [pan, setPan] = React.useState({ x: -100, y: 30 });
  const [zoom, setZoom] = React.useState(0.85);
  const [view, setView] = React.useState('graph'); // graph | source
  const dragRef = React.useRef(null);
  const surfaceRef = React.useRef(null);

  React.useEffect(() => {
    onSelectNode?.(nodes.find(n => n.id === selected) || null);
  }, [selected]);

  const onNodeMouseDown = (e, id) => {
    if (e.button !== 0) return;
    e.stopPropagation();
    setSelected(id);
    const node = nodes.find(n => n.id === id);
    const sx = e.clientX, sy = e.clientY, ox = node.x, oy = node.y;
    const move = (ev) => {
      setNodes(prev => prev.map(n => n.id === id
        ? { ...n, x: ox + (ev.clientX - sx) / zoom, y: oy + (ev.clientY - sy) / zoom }
        : n));
    };
    const up = () => { window.removeEventListener('mousemove', move); window.removeEventListener('mouseup', up); };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  };

  const onSurfaceMouseDown = (e) => {
    if (e.target.closest('.rs-gnode')) return;
    const sx = e.clientX, sy = e.clientY, op = { ...pan };
    const move = (ev) => setPan({ x: op.x + (ev.clientX - sx), y: op.y + (ev.clientY - sy) });
    const up = () => { window.removeEventListener('mousemove', move); window.removeEventListener('mouseup', up); };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  };

  React.useEffect(() => {
    const el = surfaceRef.current; if (!el) return;
    const onWheel = (e) => {
      if (!e.ctrlKey && !e.metaKey) return;
      e.preventDefault();
      setZoom(z => Math.max(0.4, Math.min(1.6, z - e.deltaY * 0.001)));
    };
    el.addEventListener('wheel', onWheel, { passive: false });
    return () => el.removeEventListener('wheel', onWheel);
  }, []);

  const nodeMap = React.useMemo(() => Object.fromEntries(nodes.map(n => [n.id, n])), [nodes]);
  const NODE_W = 220;

  const edgePath = (a, b) => {
    const x1 = a.x + NODE_W, y1 = a.y + 40;
    const x2 = b.x,           y2 = b.y + 40;
    const dx = Math.max(40, (x2 - x1) * 0.5);
    return `M ${x1} ${y1} C ${x1+dx} ${y1}, ${x2-dx} ${y2}, ${x2} ${y2}`;
  };

  return (
    <div className="rs-panel">
      <div className="rs-panel-hd">
        <div className="rs-panel-title">
          {I.graph}<span>{view === 'graph' ? 'Type Graph' : 'TradableProduct.rosetta'}</span>
          <span className="rs-panel-sub">· {nodes.length} types · {window.RUNE_DATA.GRAPH_EDGES.length} refs</span>
        </div>
        <div className="rs-panel-actions">
          <div className="rs-seg">
            <span className={view==='graph'?'is-on':''} onClick={() => setView('graph')}>Graph</span>
            <span className={view==='source'?'is-on':''} onClick={() => setView('source')}>Source</span>
          </div>
          <button className="rs-icon-btn" aria-label="Filter">{I.filter}</button>
          <button className="rs-icon-btn" aria-label="More">{I.more}</button>
        </div>
      </div>

      {view === 'graph' ? (
        <div className="rs-canvas" ref={surfaceRef} onMouseDown={onSurfaceMouseDown}>
          <div className="rs-canvas-grid"
               style={{ backgroundPosition: `${pan.x}px ${pan.y}px` }}/>
          <div className="rs-canvas-stage"
               style={{ transform: `translate(${pan.x}px,${pan.y}px) scale(${zoom})` }}>
            <svg className="rs-edges" width="1600" height="700">
              {window.RUNE_DATA.GRAPH_EDGES.map((e,i) => {
                const a = nodeMap[e.from], b = nodeMap[e.to];
                if (!a || !b) return null;
                const m = KIND_META[e.kind];
                const stroke = e.ext ? m.color : 'rgba(180,200,255,0.35)';
                const dashed = e.ext;
                const isHi = selected === e.from || selected === e.to;
                return (
                  <g key={i} opacity={isHi ? 1 : 0.55}>
                    <path d={edgePath(a,b)} fill="none"
                          stroke={stroke} strokeWidth={isHi ? 1.6 : 1.2}
                          strokeDasharray={dashed ? '4 3' : undefined}/>
                    <circle cx={b.x} cy={b.y + 40} r="2.5" fill={stroke}/>
                  </g>
                );
              })}
            </svg>

            {nodes.map(n => {
              const m = KIND_META[n.kind];
              return (
                <div key={n.id}
                     className={`rs-gnode ${selected===n.id?'is-selected':''} ${focusedNode?.id===n.id?'is-focus':''}`}
                     style={{ left: n.x, top: n.y, width: NODE_W, '--kind': m.color }}
                     onMouseDown={(e) => onNodeMouseDown(e, n.id)}
                     data-screen-label={`Node ${n.name}`}>
                  <span className="rs-gnode-port rs-gnode-port-in"/>
                  <span className="rs-gnode-port rs-gnode-port-out"/>
                  <div className="rs-gnode-head">
                    <span className="rs-gnode-glyph">{m.glyph}</span>
                    <div className="rs-gnode-meta">
                      <div className="rs-gnode-kind">{m.label}</div>
                      <div className="rs-gnode-name">{n.name}</div>
                    </div>
                    <span className="rs-gnode-card">{n.card}</span>
                  </div>
                  {n.members && (
                    <div className="rs-gnode-preview">
                      {n.members.slice(0, 3).map((mb, i) => {
                        const mk = KIND_META[mb.kind];
                        return (
                          <div key={i} className="rs-gnode-prev-row">
                            <span className="rs-gnode-prev-name">{mb.name}</span>
                            <span className="rs-gnode-prev-type" style={{ color: mk.color }}>{mb.type}</span>
                            <span className="rs-gnode-prev-card">{mb.card}</span>
                          </div>
                        );
                      })}
                      {n.members.length > 3 && <div className="rs-gnode-prev-more">+ {n.members.length - 3} more</div>}
                    </div>
                  )}
                  {!n.members && (
                    <div className="rs-gnode-foot">
                      <span className="rs-gnode-ns">{n.ns.replace('cdm.','')}</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          <div className="rs-canvas-controls">
            <button className="rs-zbtn" onClick={() => setZoom(z => Math.max(0.4, z - 0.1))}>{I.minus}</button>
            <div className="rs-zval">{Math.round(zoom*100)}%</div>
            <button className="rs-zbtn" onClick={() => setZoom(z => Math.min(1.6, z + 0.1))}>{I.plus}</button>
            <span className="rs-zsep"/>
            <button className="rs-zbtn" onClick={() => { setZoom(0.85); setPan({ x:-100, y:30 }); }} title="Fit">{I.fit}</button>
          </div>

          <div className="rs-canvas-legend">
            <div className="rs-leg-row"><span className="rs-leg-kind" style={{background:'#00D4AA'}}/> data</div>
            <div className="rs-leg-row"><span className="rs-leg-kind" style={{background:'#E8913A'}}/> choice</div>
            <div className="rs-leg-row"><span className="rs-leg-kind" style={{background:'#8B7BF4'}}/> enum</div>
            <div className="rs-leg-row"><span className="rs-leg-kind" style={{background:'#82AAFF'}}/> func</div>
            <div className="rs-leg-sep"/>
            <div className="rs-leg-row"><span className="rs-leg-ref"/> reference</div>
            <div className="rs-leg-row"><span className="rs-leg-ext"/> external</div>
          </div>
        </div>
      ) : (
        <SourceView/>
      )}
    </div>
  );
};

const SourceView = () => {
  const lines = [
    { n:1,  t:[['comment','// SPDX-License-Identifier: FSL-1.1-ALv2']] },
    { n:2,  t:[['kw','namespace'], [' ','cdm.product.template:']] },
    { n:3,  t:[['kw','version'], [' ','"7.0.0-dev.83"']] },
    { n:4,  t:[] },
    { n:5,  t:[['kw','import'], [' cdm.base.staticdata.party.* ']] },
    { n:6,  t:[['kw','import'], [' cdm.event.common.*']] },
    { n:7,  t:[] },
    { n:8,  t:[['comment','/// A product that may be traded between counterparties.']] },
    { n:9,  t:[['kw','type'], [' '], ['type','TradableProduct'], [':']] },
    { n:10, t:[[' ',' product'], [' '], ['type','NonTransferableProduct'], [' '], ['card','(1..1)']] },
    { n:11, t:[[' ',' tradeLot'], [' '], ['type','TradeLot'], [' '], ['card','(1..*)']] },
    { n:12, t:[[' ',' counterparty'], [' '], ['type','Counterparty'], [' '], ['card','(2..2)']] },
    { n:13, t:[[' ',' ancillaryParty'], [' '], ['type','AncillaryParty'], [' '], ['card','(0..*)']] },
    { n:14, t:[[' ',' adjustment'], [' '], ['type','NotionalAdjustment'], [' '], ['card','(0..1)']] },
    { n:15, t:[] },
    { n:16, t:[[' ',' condition '], ['type','PriceQuantityResolution'], [':']] },
    { n:17, t:[[' ','  if '], ['kw','count'], ['op','('], ['id','tradeLot'], ['op',')'], [' '], ['op','>'], [' '], ['num','0']] },
    { n:18, t:[[' ','  then '], ['id','tradeLot'], ['op',' -> '], ['id','priceQuantity '], ['kw','exists']] },
  ];
  const cls = (t) => t === ' ' ? null : `tok-${t}`;
  return (
    <div className="rs-canvas" style={{padding:'14px 18px',background:'var(--rs-bg-2)'}}>
      <div className="rs-code">
        {lines.map(line => (
          <div key={line.n} className="rs-code-line">
            <span className="rs-code-gutter">{line.n}</span>
            <span className="rs-code-text">
              {line.t.map(([k,txt],i) => k===' ' ? txt : <span key={i} className={cls(k)}>{txt}</span>)}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

window.GraphPanel = GraphPanel;
