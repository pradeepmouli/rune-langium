// FormPreview — preview of an instance form generated from the current type.
// Mirrors apps/studio's FormPreviewPanel: it's the *runtime* form, not the
// type editor. Lives as its own panel so users can author an instance against
// the schema without leaving the workspace.
const FormPreview = ({ selectedNode }) => {
  const node = selectedNode || window.RUNE_DATA.GRAPH_NODES[0];
  const km = window.RUNE_DATA.KINDS[node.kind] || window.RUNE_DATA.KINDS.data;

  const members = node.members || [
    { name:'product',         type:'NonTransferableProduct', kind:'data',   card:'1..1', input:'ref',  placeholder:'Select product…' },
    { name:'tradeLot',        type:'TradeLot',               kind:'data',   card:'1..*', input:'list', itemType:'ref' },
    { name:'counterparty',    type:'Counterparty',           kind:'data',   card:'2..2', input:'list', itemType:'ref', fixed:2 },
    { name:'ancillaryParty',  type:'AncillaryParty',         kind:'data',   card:'0..*', input:'list', itemType:'ref' },
    { name:'adjustment',      type:'NotionalAdjustment',     kind:'enum',   card:'0..1', input:'enum',
        options:['Execution','PortfolioRebalancing','Compression'] },
    { name:'sourceRef',       type:'string',                 kind:'data',   card:'0..1', input:'text', placeholder:'urn:cdm:trade:…' },
  ];

  const refOptions = {
    NonTransferableProduct: ['ntp_irs_5y_usd','ntp_fxfwd_eurusd','ntp_eq_aapl'],
    TradeLot:               ['lot.001','lot.002','lot.003'],
    Counterparty:           ['party_acme','party_globex','party_initech','party_umbrella'],
    AncillaryParty:         ['calc_agent_jpm','custodian_bnym'],
  };

  const [val, setVal] = React.useState({
    product: 'ntp_irs_5y_usd',
    tradeLot: ['lot.001'],
    counterparty: ['party_acme', 'party_globex'],
    ancillaryParty: [],
    adjustment: 'Execution',
    sourceRef: 'urn:cdm:trade:7f3e-219',
  });
  const [view, setView] = React.useState('form'); // form | json
  const lastNode = React.useRef(node.id);
  React.useEffect(() => {
    if (lastNode.current !== node.id) {
      lastNode.current = node.id;
      setVal({
        product: 'ntp_irs_5y_usd',
        tradeLot: ['lot.001'],
        counterparty: ['party_acme', 'party_globex'],
        ancillaryParty: [],
        adjustment: 'Execution',
        sourceRef: '',
      });
    }
  }, [node.id]);

  const set     = (k, v) => setVal(s => ({ ...s, [k]: v }));
  const setItem = (k, i, v) => setVal(s => ({ ...s, [k]: s[k].map((x, idx) => idx === i ? v : x) }));
  const addItem = (k) => setVal(s => ({ ...s, [k]: [...s[k], ''] }));
  const rmItem  = (k, i) => setVal(s => ({ ...s, [k]: s[k].filter((_, idx) => idx !== i) }));

  const validate = (m) => {
    const v = val[m.name];
    const min = m.card.startsWith('0') ? 0 : m.card.startsWith('2') ? 2 : 1;
    if (m.input === 'list') {
      if (m.fixed && (v||[]).length !== m.fixed) return `expected ${m.fixed}, got ${(v||[]).length}`;
      if ((v||[]).length < min) return `min ${min}, got ${(v||[]).length}`;
      if ((v||[]).some(x => !x)) return 'empty value';
    } else if (min > 0 && (!v || v === '')) return 'required';
    return null;
  };

  const errors = members.map(validate).filter(Boolean).length;
  const json = JSON.stringify({ "@type": node.name, ...val }, null, 2);

  return (
    <div className="rs-panel">
      <div className="rs-panel-hd">
        <div className="rs-panel-title">
          <span className="rs-insp-glyph"
                style={{
                  color: km.color,
                  background: `color-mix(in oklch, ${km.color}, transparent 84%)`,
                  borderColor: `color-mix(in oklch, ${km.color}, transparent 60%)`,
                }}>{km.glyph}</span>
          <span style={{fontSize:13}}>Form preview</span>
          <span className="rs-panel-sub">· {node.name}</span>
        </div>
        <div className="rs-panel-actions">
          <div className="rs-seg">
            <span className={view==='form'?'is-on':''} onClick={() => setView('form')}>Form</span>
            <span className={view==='json'?'is-on':''} onClick={() => setView('json')}>JSON</span>
          </div>
          <button className="rs-icon-btn" aria-label="Validate" title="Validate"><Ic><path d="M5 12l5 5L20 6"/></Ic></button>
          <button className="rs-icon-btn" aria-label="More">{I.more}</button>
        </div>
      </div>

      <div className="rs-form-meta">
        <span className={`rs-form-status ${errors?'is-err':'is-ok'}`}>
          {errors ? <Ic><circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16.5v.1"/></Ic>
                  : <Ic><path d="M5 12l5 5L20 6"/></Ic>}
          <span>{errors ? `${errors} validation issue${errors>1?'s':''}` : 'instance valid'}</span>
        </span>
        <span className="rs-form-meta-spacer"/>
        <span className="rs-form-meta-stat">draft · {Object.keys(val).length} fields</span>
      </div>

      <div className="rs-insp-body">
        {view === 'form' && (
          <div className="rs-form">
            {members.map((m, i) => {
              const mk = window.RUNE_DATA.KINDS[m.kind] || window.RUNE_DATA.KINDS.data;
              const err = validate(m);
              return (
                <div key={i} className="rs-field" data-noncommentable="">
                  <div className="rs-field-row">
                    <span className="rs-field-name">{m.name}</span>
                    <span className="rs-field-card">{m.card}</span>
                  </div>
                  <div className="rs-field-row rs-field-row-2">
                    <span className="rs-field-type" style={{color:mk.color}}>
                      <span className="rs-field-type-glyph"
                            style={{ color:mk.color,
                                     background:`color-mix(in oklch, ${mk.color}, transparent 82%)` }}>{mk.glyph}</span>
                      {m.type}
                    </span>
                    {err
                      ? <span className="rs-field-meta" style={{color:'var(--rs-err)'}}>⚠ {err}</span>
                      : <span className="rs-field-meta">edited</span>}
                  </div>

                  {m.input === 'text' && (
                    <input className="rs-field-input" value={val[m.name] || ''}
                           placeholder={m.placeholder}
                           onChange={e => set(m.name, e.target.value)}/>
                  )}

                  {m.input === 'enum' && (
                    <div style={{display:'flex',gap:4,marginTop:4,flexWrap:'wrap'}}>
                      {m.options.map(o => (
                        <button key={o}
                                onClick={() => set(m.name, o)}
                                style={{
                                  appearance:'none',border:`0.5px solid ${val[m.name]===o
                                    ? mk.color : 'var(--rs-line-2)'}`,
                                  background: val[m.name]===o
                                    ? `color-mix(in oklch, ${mk.color}, transparent 82%)`
                                    : 'var(--rs-bg-2)',
                                  color: val[m.name]===o ? mk.color : 'var(--rs-fg-2)',
                                  padding:'4px 9px',borderRadius:6,fontSize:11.5,
                                  fontFamily:'var(--rs-font-mono)',
                                }}>{o}</button>
                      ))}
                    </div>
                  )}

                  {m.input === 'ref' && (
                    <select className="rs-field-input"
                            value={val[m.name] || ''}
                            onChange={e => set(m.name, e.target.value)}
                            style={{appearance:'auto'}}>
                      <option value="">— select —</option>
                      {(refOptions[m.type] || []).map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                  )}

                  {m.input === 'list' && (
                    <div style={{display:'flex',flexDirection:'column',gap:4,marginTop:4}}>
                      {(val[m.name] || []).map((v, idx) => (
                        <div key={idx} style={{display:'flex',gap:4}}>
                          <select className="rs-field-input"
                                  value={v} onChange={e => setItem(m.name, idx, e.target.value)}
                                  style={{appearance:'auto',marginTop:0,flex:1}}>
                            <option value="">— select —</option>
                            {(refOptions[m.type] || []).map(o =>
                              <option key={o} value={o}>{o}</option>)}
                          </select>
                          {!m.fixed && (
                            <button className="rs-icon-btn"
                                    onClick={() => rmItem(m.name, idx)}
                                    aria-label="Remove">{I.x}</button>
                          )}
                        </div>
                      ))}
                      {!m.fixed && (
                        <button className="rs-pill"
                                style={{alignSelf:'flex-start',marginTop:2}}
                                onClick={() => addItem(m.name)}>
                          {I.plus}<span>add {m.name}</span>
                        </button>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {view === 'json' && (
          <div className="rs-code" style={{whiteSpace:'pre-wrap',padding:'2px 2px'}}>
            {json.split('\n').map((line, i) => (
              <div key={i} className="rs-code-line">
                <span className="rs-code-gutter">{i+1}</span>
                <span className="rs-code-text">{syntaxJson(line)}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

// ── JSON syntax highlighter (used by FormPreview JSON view) ──────────────
function syntaxJson(line) {
  const out = [];
  let rest = line;
  const ws = rest.match(/^\s*/)[0];
  if (ws) out.push(ws);
  rest = rest.slice(ws.length);
  const km = rest.match(/^"([^"]*)"(\s*:\s*)/);
  if (km) {
    out.push(<span key="k" className="tok-meta">"{km[1]}"</span>);
    out.push(<span key="c" className="tok-op">{km[2]}</span>);
    rest = rest.slice(km[0].length);
  }
  if (rest.startsWith('"')) {
    const m = rest.match(/^"([^"]*)"/);
    if (m) { out.push(<span key="s" className="tok-str">"{m[1]}"</span>); rest = rest.slice(m[0].length); }
  } else if (/^-?\d/.test(rest)) {
    const m = rest.match(/^-?\d+(\.\d+)?/);
    if (m) { out.push(<span key="n" className="tok-num">{m[0]}</span>); rest = rest.slice(m[0].length); }
  } else if (/^(true|false|null)/.test(rest)) {
    const m = rest.match(/^(true|false|null)/);
    out.push(<span key="b" className="tok-kw">{m[0]}</span>); rest = rest.slice(m[0].length);
  }
  out.push(<span key="r" className="tok-op">{rest}</span>);
  return out;
}

window.FormPreview = FormPreview;
