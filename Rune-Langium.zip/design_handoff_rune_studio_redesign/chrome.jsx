// Activity rail, top bar, status bar, command palette
const ActivityRail = ({ active, onActive }) => {
  const items = [
    { id:'files',    icon:I.files,  label:'Explorer' },
    { id:'graph',    icon:I.graph,  label:'Graph' },
    { id:'search',   icon:I.search, label:'Search' },
    { id:'models',   icon:I.models, label:'Curated models' },
    { id:'ghub',     icon:I.ghub,   label:'Source control', badge:2 },
  ];
  return (
    <aside className="rs-rail" data-noncommentable="">
      <div className="rs-rail-mark"><RuneMark size={26}/></div>
      <div className="rs-rail-group">
        {items.map(it => (
          <button key={it.id} className={`rs-rail-btn ${active===it.id ? 'is-active':''}`}
                  onClick={() => onActive(it.id)} aria-label={it.label} title={it.label}>
            {active===it.id && <span className="rs-rail-pip"/>}
            {it.icon}
            {it.badge ? <span className="rs-rail-badge">{it.badge}</span> : null}
          </button>
        ))}
      </div>
      <div className="rs-rail-spacer"/>
      <div className="rs-rail-group">
        <button className="rs-rail-btn" aria-label="Notifications"><Ic d={null}><path d="M6 8a6 6 0 1 1 12 0c0 7 3 9 3 9H3s3-2 3-9M9 21a3 3 0 0 0 6 0"/></Ic></button>
        <button className="rs-rail-btn" aria-label="Settings">{I.gear}</button>
      </div>
    </aside>
  );
};

const TopBar = ({ tabs, activeTab, onTab, runState, onRun, onCmdK, lspState }) => {
  const t = tabs.find(t => t.id === activeTab) || tabs[0];
  const fileName = (t?.name || '').split('/').pop();
  return (
    <header className="rs-top" data-noncommentable="">
      <div className="rs-top-l">
        <button className="rs-ws">
          <span className="rs-ws-mark"><RuneMark size={12}/></span>
          <span className="rs-ws-name">cdm-7.0.0-dev.83</span>
          <span className="rs-ws-sub">· master</span>
          {I.chevD}
        </button>
        <span className="rs-divider-v"/>
        <div className="rs-tabs">
          {tabs.map(t => (
            <button key={t.id} className={`rs-tab ${activeTab===t.id?'is-active':''}`} onClick={() => onTab(t.id)}>
              <span className={`rs-tab-dot ${t.dirty?'is-dirty':''}`}/>
              <span className="rs-tab-name">{t.name.split('/').pop()}</span>
              {t.errors > 0 && <span className="rs-tab-bad rs-bad-err"><span className="rs-bad-err-dot"/>{t.errors}</span>}
              {t.warnings > 0 && t.errors === 0 && <span className="rs-tab-bad rs-bad-warn"><span className="rs-bad-warn-dot"/>{t.warnings}</span>}
              <span className="rs-tab-x">{I.x}</span>
            </button>
          ))}
          <button className="rs-tab-add" aria-label="New file">{I.plus}</button>
        </div>
      </div>
      <div className="rs-top-r">
        <button className="rs-cmdk" onClick={onCmdK}>
          {I.search}<span>Search types, files, commands…</span><kbd>⌘K</kbd>
        </button>
        <span className="rs-divider-v"/>
        <button className="rs-icon-btn" aria-label="Validate" title="Validate">
          <Ic><path d="M5 12l5 5L20 6"/></Ic>
        </button>
        <button className="rs-icon-btn" aria-label="Export code" title="Export code">{I.download}</button>
        <button className="rs-icon-btn" aria-label="Share" title="Share">{I.share}</button>
        <button className={`rs-btn rs-btn-primary ${runState==='running'?'is-running':''}`} onClick={onRun}>
          {runState==='running' ? I.stop : I.bolt}
          {runState==='running' ? 'Stop' : 'Generate'}
        </button>
        <span className="rs-divider-v"/>
        <button className="rs-avatar" aria-label="Account">PM</button>
      </div>
    </header>
  );
};

const StatusBar = ({ workspace, gitState, lspState, telemetry, onTelemetry }) => {
  return (
    <footer className="rs-status" data-noncommentable="">
      <div className="rs-status-grp">
        <span className="rs-status-pill">⟢ {workspace}</span>
        <span className="rs-status-sep"/>
        <span className="rs-status-pill">{gitState}</span>
        <span className="rs-status-sep"/>
        <span className="rs-status-pill">
          <span className="rs-conn-dot connected"/>
          lsp · {lspState} · ws://localhost:3001
        </span>
      </div>
      <div className="rs-status-grp rs-status-r">
        <span className="rs-status-pill">utf-8</span>
        <span className="rs-status-pill">spaces: 2</span>
        <span className="rs-status-pill">rosetta · v9.27</span>
        <span className="rs-status-sep"/>
        <button className="rs-status-btn" onClick={onTelemetry}>
          {telemetry ? '◉' : '○'} diagnostics
        </button>
      </div>
    </footer>
  );
};

const CommandPalette = ({ open, onClose }) => {
  const [q, setQ] = React.useState('');
  const [idx, setIdx] = React.useState(0);
  React.useEffect(() => { if (open) { setQ(''); setIdx(0); } }, [open]);
  if (!open) return null;
  const groups = [
    { label:'Types', items:[
      { icon:'D', kind:'data',   label:'TradableProduct',   sub:'cdm.product.template' },
      { icon:'D', kind:'data',   label:'EconomicTerms',     sub:'cdm.product.template' },
      { icon:'C', kind:'choice', label:'Payout',            sub:'cdm.product.common'   },
      { icon:'E', kind:'enum',   label:'NotionalAdjustment',sub:'cdm.product.template' },
    ]},
    { label:'Commands', items:[
      { icon:'⏵', label:'Run validation',            sub:'R' },
      { icon:'↓', label:'Export code…',              sub:'⌘ E' },
      { icon:'+', label:'New file…',                 sub:'⌘ N' },
      { icon:'⤓', label:'Pull latest',               sub:'⌘ ⇧ P' },
      { icon:'⌥', label:'Toggle inspector',          sub:'⌘ I' },
    ]},
  ];
  const filtered = groups.map(g => ({...g, items: g.items.filter(it =>
    !q || it.label.toLowerCase().includes(q.toLowerCase()))})).filter(g => g.items.length);
  const total = filtered.reduce((a,g) => a + g.items.length, 0);
  const KIND_C = { data:'#00D4AA', choice:'#E8913A', enum:'#8B7BF4', func:'#82AAFF' };
  return (
    <div className="rs-cmdk-bg" onClick={onClose}>
      <div className="rs-cmdk-modal" onClick={e => e.stopPropagation()}>
        <div className="rs-cmdk-input">
          {I.search}
          <input autoFocus value={q} onChange={e => { setQ(e.target.value); setIdx(0); }}
                 placeholder="Search types, files, commands…"
                 onKeyDown={e => {
                   if (e.key==='ArrowDown') { setIdx(i => Math.min(total-1, i+1)); e.preventDefault(); }
                   if (e.key==='ArrowUp')   { setIdx(i => Math.max(0, i-1));       e.preventDefault(); }
                   if (e.key==='Escape')    onClose();
                 }}/>
          <kbd>esc</kbd>
        </div>
        <div className="rs-cmdk-list">
          {total === 0 ? <div className="rs-cmdk-empty">No matches for "{q}"</div> :
            (() => { let n = 0; return filtered.map((g, gi) => (
              <div key={gi}>
                <div className="rs-cmdk-grp-h">{g.label}</div>
                {g.items.map((it,i) => {
                  const isOn = n === idx; n++;
                  return (
                    <button key={i} className={`rs-cmdk-row ${isOn?'is-on':''}`}>
                      <span className="rs-cmdk-icon"
                            style={it.kind ? { color:KIND_C[it.kind], background:`color-mix(in oklch, ${KIND_C[it.kind]}, transparent 80%)` } : null}>
                        {it.icon}
                      </span>
                      <span className="rs-cmdk-label">{it.label}</span>
                      <span style={{fontSize:11,fontFamily:'var(--rs-font-mono)',color:'var(--rs-fg-4)'}}>{it.sub}</span>
                    </button>
                  );
                })}
              </div>
            )); })()}
        </div>
        <div className="rs-cmdk-hint">
          <span><kbd>↑↓</kbd> navigate</span>
          <span><kbd>↵</kbd> open</span>
          <span><kbd>⌘ ↵</kbd> open in split</span>
        </div>
      </div>
    </div>
  );
};

Object.assign(window, { ActivityRail, TopBar, StatusBar, CommandPalette });
