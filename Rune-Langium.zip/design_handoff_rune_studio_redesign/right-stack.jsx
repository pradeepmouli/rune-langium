// RightStack — right column. Stacks the *output views* of the type:
//   • Code        — generated source in TS / Java / Py / JSON
//   • Form preview — instance form rendered from the schema
//
// Both are derived from the type definition currently being edited in the
// workspace. Tabbed switcher at the top, body fills the rest.

const RightStack = ({ selectedNode, codegenTarget, onCodegenTarget,
                     activeView, onActiveView, onClose }) => {
  return (
    <div className="rs-right">
      <div className="rs-right-tabs">
        <button className={`rs-right-tab ${activeView==='code'?'is-on':''}`}
                onClick={() => onActiveView('code')}>
          <span className="rs-right-tab-glyph">{I.bolt}</span>
          <span>Code</span>
        </button>
        <button className={`rs-right-tab ${activeView==='form'?'is-on':''}`}
                onClick={() => onActiveView('form')}>
          <span className="rs-right-tab-glyph">{I.eye}</span>
          <span>Form preview</span>
        </button>
        <span className="rs-right-tabs-spacer"/>
        {activeView === 'code' && (
          <div className="rs-seg" style={{marginRight:4}}>
            {['TS','Java','Py','JSON'].map(t => (
              <span key={t}
                    className={codegenTarget===t?'is-on':''}
                    onClick={() => onCodegenTarget(t)}>{t}</span>
            ))}
          </div>
        )}
        <button className="rs-icon-btn" aria-label="Close panel" onClick={onClose}>{I.x}</button>
      </div>
      <div className="rs-right-body">
        {activeView === 'code' && <CodeView target={codegenTarget}/>}
        {activeView === 'form' && <FormPreview selectedNode={selectedNode}/>}
      </div>
    </div>
  );
};

window.RightStack = RightStack;
