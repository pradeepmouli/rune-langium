// Workspace — center column with multi-select panes (Graph / Source / Inspector).
// These are three views of the SAME type definition: visual graph, .rosetta
// source text, and structural inspector. Mirrors the real Rune Studio editor.

const Workspace = ({ runState, onSelectNode, selectedNode, focusedNode,
                    panes, onPanesChange }) => {
  const has = (id) => panes.includes(id);
  const toggle = (id) => {
    if (has(id) && panes.length === 1) return;          // never lose all panes
    const PRIORITY = ['graph','source','inspector'];
    if (has(id)) onPanesChange(panes.filter(p => p !== id));
    else onPanesChange([...panes, id].sort((a,b) => PRIORITY.indexOf(a) - PRIORITY.indexOf(b)));
  };

  const PANE_DEFS = [
    { id:'graph',     label:'Graph',     icon: I.graph },
    { id:'source',    label:'Source',    icon: I.files },
    { id:'inspector', label:'Inspector', icon: I.models },
  ];

  return (
    <div className="rs-stack">
      <div className="rs-stack-bar">
        <div className="rs-paneswitch" role="group" aria-label="Workspace panes">
          {PANE_DEFS.map(p => (
            <button key={p.id}
                    className={`rs-paneswitch-seg ${has(p.id)?'is-on':''}`}
                    aria-pressed={has(p.id)}
                    onClick={() => toggle(p.id)}>
              {p.icon}<span>{p.label}</span>
            </button>
          ))}
        </div>
        <div className="rs-stack-bar-right">
          <button className="rs-icon-btn" aria-label="Filter">{I.filter}</button>
          <button className="rs-icon-btn" aria-label="More">{I.more}</button>
        </div>
      </div>
      <div className="rs-stack-body" data-count={panes.length}>
        {panes.map((id, i) => (
          <React.Fragment key={id}>
            {i > 0 && <div className="rs-stack-split"/>}
            <div className="rs-stack-pane" data-pane={id}>
              {id === 'graph'     && <GraphView runState={runState}
                                                onSelectNode={onSelectNode}
                                                focusedNode={focusedNode}/>}
              {id === 'source'    && <SourceView/>}
              {id === 'inspector' && <Inspector selectedNode={selectedNode}/>}
            </div>
          </React.Fragment>
        ))}
      </div>
    </div>
  );
};

// ── Graph view (extracted from previous GraphPanel body) ──────────────────
const GraphView = ({ runState, onSelectNode, focusedNode }) => {
  const RAW_NODES = window.RUNE_DATA.GRAPH_NODES;
  const [orientation, setOrientation] = React.useState('horizontal');
  const [nodes, setNodes] = React.useState(RAW_NODES);
  const [selected, setSelected] = React.useState('TradableProduct');
  const [pan, setPan] = React.useState({ x: -100, y: 30 });
  const [zoom, setZoom] = React.useState(0.85);
  const surfaceRef = React.useRef(null);

  // Auto-orient based on the canvas's own aspect ratio. Horizontal layout
  // (left→right flow) when wider than tall, vertical (top→bottom) otherwise.
  React.useEffect(() => {
    const el = surfaceRef.current; if (!el) return;
    const ro = new ResizeObserver(() => {
      const { clientWidth: w, clientHeight: h } = el;
      if (!w || !h) return;
      const next = w >= h ? 'horizontal' : 'vertical';
      setOrientation(prev => prev === next ? prev : next);
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  // Re-layout nodes whenever orientation flips. Horizontal uses raw (x,y);
  // vertical swaps axes (and rescales) so columns become rows.
  React.useEffect(() => {
    if (orientation === 'horizontal') {
      setNodes(RAW_NODES.map(n => ({ ...n })));
      setPan({ x: -100, y: 30 });
    } else {
      // Swap axes; raw x range ~240–1100, y range ~90–380. After swap,
      // x becomes y (depth) and y becomes x (siblings). Compress the
      // depth axis a touch since rows are taller than columns are wide.
      setNodes(RAW_NODES.map(n => ({ ...n,
        x: (n.y - 90) * 1.6 + 60,            // siblings spread horizontally
        y: (n.x - 240) * 0.55 + 30,          // depth flows top→bottom
      })));
      setPan({ x: 20, y: 0 });
    }
  }, [orientation]);

  React.useEffect(() => {
    onSelectNode?.(nodes.find(n => n.id === selected) || null);
  }, [selected]);

  const onNodeMouseDown = (e, id) => {
    if (e.button !== 0) return;
    e.stopPropagation();
    setSelected(id);
    const node = nodes.find(n => n.id === id);
    const sx = e.clientX, sy = e.clientY, ox = node.x, oy = node.y;
    const move = (ev) => {
      setNodes(prev => prev.map(n => n.id === id
        ? { ...n, x: ox + (ev.clientX - sx) / zoom, y: oy + (ev.clientY - sy) / zoom }
        : n));
    };
    const up = () => { window.removeEventListener('mousemove', move); window.removeEventListener('mouseup', up); };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  };

  const onSurfaceMouseDown = (e) => {
    if (e.target.closest('.rs-gnode')) return;
    const sx = e.clientX, sy = e.clientY, op = { ...pan };
    const move = (ev) => setPan({ x: op.x + (ev.clientX - sx), y: op.y + (ev.clientY - sy) });
    const up = () => { window.removeEventListener('mousemove', move); window.removeEventListener('mouseup', up); };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  };

  React.useEffect(() => {
    const el = surfaceRef.current; if (!el) return;
    const onWheel = (e) => {
      if (!e.ctrlKey && !e.metaKey) return;
      e.preventDefault();
      setZoom(z => Math.max(0.4, Math.min(1.6, z - e.deltaY * 0.001)));
    };
    el.addEventListener('wheel', onWheel, { passive: false });
    return () => el.removeEventListener('wheel', onWheel);
  }, []);

  const nodeMap = React.useMemo(() => Object.fromEntries(nodes.map(n => [n.id, n])), [nodes]);
  const NODE_W = 220;
  const NODE_H = 88;   // approximate; for vertical edge attach
  const edgePath = (a, b) => {
    if (orientation === 'horizontal') {
      // Right side of a → left side of b
      const x1 = a.x + NODE_W, y1 = a.y + 40;
      const x2 = b.x,           y2 = b.y + 40;
      const dx = Math.max(40, (x2 - x1) * 0.5);
      return `M ${x1} ${y1} C ${x1+dx} ${y1}, ${x2-dx} ${y2}, ${x2} ${y2}`;
    } else {
      // Bottom of a → top of b
      const x1 = a.x + NODE_W/2, y1 = a.y + NODE_H;
      const x2 = b.x + NODE_W/2, y2 = b.y;
      const dy = Math.max(30, (y2 - y1) * 0.5);
      return `M ${x1} ${y1} C ${x1} ${y1+dy}, ${x2} ${y2-dy}, ${x2} ${y2}`;
    }
  };
  const edgeTerminal = (b) => orientation === 'horizontal'
    ? { cx: b.x,            cy: b.y + 40 }
    : { cx: b.x + NODE_W/2, cy: b.y };

  return (
    <div className="rs-canvas" ref={surfaceRef} onMouseDown={onSurfaceMouseDown}>
      <div className="rs-canvas-grid" style={{ backgroundPosition: `${pan.x}px ${pan.y}px` }}/>
      <div className={`rs-canvas-stage rs-canvas-stage--${orientation}`} style={{ transform: `translate(${pan.x}px,${pan.y}px) scale(${zoom})` }}>
        <svg className="rs-edges" width="1600" height="700">
          {window.RUNE_DATA.GRAPH_EDGES.map((e,i) => {
            const a = nodeMap[e.from], b = nodeMap[e.to];
            if (!a || !b) return null;
            const m = window.RUNE_DATA.KINDS[e.kind];
            const stroke = e.ext ? m.color : 'rgba(180,200,255,0.35)';
            const isHi = selected === e.from || selected === e.to;
            return (
              <g key={i} opacity={isHi ? 1 : 0.55}>
                <path d={edgePath(a,b)} fill="none" stroke={stroke}
                      strokeWidth={isHi ? 1.6 : 1.2}
                      strokeDasharray={e.ext ? '4 3' : undefined}/>
                {(() => { const t = edgeTerminal(b); return (
                  <circle cx={t.cx} cy={t.cy} r="2.5" fill={stroke}/>
                ); })()}
              </g>
            );
          })}
        </svg>
        {nodes.map(n => {
          const m = window.RUNE_DATA.KINDS[n.kind];
          return (
            <div key={n.id}
                 className={`rs-gnode ${selected===n.id?'is-selected':''} ${focusedNode?.id===n.id?'is-focus':''}`}
                 style={{ left: n.x, top: n.y, width: NODE_W, '--kind': m.color }}
                 onMouseDown={(e) => onNodeMouseDown(e, n.id)}
                 data-screen-label={`Node ${n.name}`}>
              <span className="rs-gnode-port rs-gnode-port-in"/>
              <span className="rs-gnode-port rs-gnode-port-out"/>
              <div className="rs-gnode-head">
                <span className="rs-gnode-glyph">{m.glyph}</span>
                <div className="rs-gnode-meta">
                  <div className="rs-gnode-kind">{m.label}</div>
                  <div className="rs-gnode-name">{n.name}</div>
                </div>
                <span className="rs-gnode-card">{n.card}</span>
              </div>
              {n.members && (
                <div className="rs-gnode-preview">
                  {n.members.slice(0, 3).map((mb, i) => {
                    const mk = window.RUNE_DATA.KINDS[mb.kind];
                    return (
                      <div key={i} className="rs-gnode-prev-row">
                        <span className="rs-gnode-prev-name">{mb.name}</span>
                        <span className="rs-gnode-prev-type" style={{ color: mk.color }}>{mb.type}</span>
                        <span className="rs-gnode-prev-card">{mb.card}</span>
                      </div>
                    );
                  })}
                  {n.members.length > 3 && <div className="rs-gnode-prev-more">+ {n.members.length - 3} more</div>}
                </div>
              )}
              {!n.members && (
                <div className="rs-gnode-foot"><span className="rs-gnode-ns">{n.ns.replace('cdm.','')}</span></div>
              )}
            </div>
          );
        })}
      </div>
      <div className="rs-canvas-controls">
        <button className="rs-zbtn" onClick={() => setZoom(z => Math.max(0.4, z - 0.1))}>{I.minus}</button>
        <div className="rs-zval">{Math.round(zoom*100)}%</div>
        <button className="rs-zbtn" onClick={() => setZoom(z => Math.min(1.6, z + 0.1))}>{I.plus}</button>
        <span className="rs-zsep"/>
        <button className="rs-zbtn" onClick={() => { setZoom(0.85); setPan({ x:-100, y:30 }); }}>{I.fit}</button>
      </div>
      <div className="rs-canvas-legend">
        <div className="rs-leg-row"><span className="rs-leg-kind" style={{background:'#00D4AA'}}/> data</div>
        <div className="rs-leg-row"><span className="rs-leg-kind" style={{background:'#E8913A'}}/> choice</div>
        <div className="rs-leg-row"><span className="rs-leg-kind" style={{background:'#8B7BF4'}}/> enum</div>
        <div className="rs-leg-row"><span className="rs-leg-kind" style={{background:'#82AAFF'}}/> func</div>
        <div className="rs-leg-sep"/>
        <div className="rs-leg-row"><span className="rs-leg-ref"/> reference</div>
        <div className="rs-leg-row"><span className="rs-leg-ext"/> external</div>
      </div>
    </div>
  );
};

// ── Source view: the .rune / .rosetta DSL editor ─────────────────────────
const SourceView = () => {
  const lines = [
    { n:1,  t:[['comment','// SPDX-License-Identifier: FSL-1.1-ALv2']] },
    { n:2,  t:[['kw','namespace'], [' ','cdm.product.template:']] },
    { n:3,  t:[['kw','version'], [' ','"7.0.0-dev.83"']] },
    { n:4,  t:[] },
    { n:5,  t:[['kw','import'], [' cdm.base.staticdata.party.* ']] },
    { n:6,  t:[['kw','import'], [' cdm.event.common.*']] },
    { n:7,  t:[] },
    { n:8,  t:[['comment','/// A product that may be traded between counterparties.']] },
    { n:9,  t:[['kw','type'], [' '], ['type','TradableProduct'], [':']] },
    { n:10, t:[[' ',' product'], [' '], ['type','NonTransferableProduct'], [' '], ['card','(1..1)']] },
    { n:11, t:[[' ',' tradeLot'], [' '], ['type','TradeLot'], [' '], ['card','(1..*)']] },
    { n:12, t:[[' ',' counterparty'], [' '], ['type','Counterparty'], [' '], ['card','(2..2)']] },
    { n:13, t:[[' ',' ancillaryParty'], [' '], ['type','AncillaryParty'], [' '], ['card','(0..*)']] },
    { n:14, t:[[' ',' adjustment'], [' '], ['type','NotionalAdjustment'], [' '], ['card','(0..1)']] },
    { n:15, t:[] },
    { n:16, t:[[' ',' condition '], ['type','PriceQuantityResolution'], [':']] },
    { n:17, t:[[' ','  if '], ['kw','count'], ['op','('], ['id','tradeLot'], ['op',')'], [' '], ['op','>'], [' '], ['num','0']] },
    { n:18, t:[[' ','  then '], ['id','tradeLot'], ['op',' -> '], ['id','priceQuantity '], ['kw','exists']] },
  ];
  return (
    <div className="rs-pane-body rs-pane-source">
      <div className="rs-source-meta">
        <span className="rs-pill rs-pill-soft">.rosetta</span>
        <span className="rs-source-path">cdm/product/template/TradableProduct.rosetta</span>
        <span className="rs-source-spacer"/>
        <span className="rs-source-stat">UTF-8 · LF · 18 lines</span>
      </div>
      <div className="rs-code">
        {lines.map(line => (
          <div key={line.n} className="rs-code-line">
            <span className="rs-code-gutter">{line.n}</span>
            <span className="rs-code-text">
              {line.t.map(([k,txt],i) => k===' ' ? txt : <span key={i} className={`tok-${k}`}>{txt}</span>)}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

// ── Code view: codegen output ─────────────────────────────────────────────
const CodeView = ({ target }) => {
  const SNIPPETS = {
    TS: [
      ['comment','// Generated by @rune-langium/codegen — DO NOT EDIT'],
      ['kw','import'], [' ',' { z } '], ['kw','from'], [' ',' '], ['str',"'zod'"], ['op',';\n\n'],
      ['comment','/** A product that may be traded between counterparties. */\n'],
      ['kw','export const'], [' ',' '], ['type','TradableProduct'], [' ',' = '], ['id','z'], ['op','.'], ['id','object'], ['op','({\n'],
      [' ','  product'], ['op',':'], [' ',' '], ['id','NonTransferableProductSchema'], ['op',',\n'],
      [' ','  tradeLot'], ['op',':'], [' ',' '], ['id','z'], ['op','.'], ['id','array'], ['op','('], ['id','TradeLotSchema'], ['op',').min('], ['num','1'], ['op','),\n'],
      [' ','  counterparty'], ['op',':'], [' ',' '], ['id','z'], ['op','.'], ['id','array'], ['op','('], ['id','CounterpartySchema'], ['op',').length('], ['num','2'], ['op','),\n'],
      [' ','  ancillaryParty'], ['op',':'], [' ',' '], ['id','z'], ['op','.'], ['id','array'], ['op','('], ['id','AncillaryPartySchema'], ['op','),\n'],
      [' ','  adjustment'], ['op',':'], [' ',' '], ['id','NotionalAdjustmentEnum'], ['op','.'], ['id','optional'], ['op','(),\n'],
      ['op','});\n'],
    ],
    Java: [
      ['comment','// Generated by @rune-langium/codegen — DO NOT EDIT'],
      ['kw','package'], [' ',' cdm.product.template;\n\n'],
      ['meta','@RosettaDataType'], ['op','('], ['str','"TradableProduct"'], ['op',')\n'],
      ['kw','public class'], [' ',' '], ['type','TradableProduct'], [' ',' '], ['kw','implements'], [' ',' '], ['type','RosettaModelObject'], [' ','{\n'],
      [' ','  '], ['kw','private final'], [' ',' '], ['type','NonTransferableProduct'], [' ',' product;\n'],
      [' ','  '], ['kw','private final'], [' ',' List<TradeLot> tradeLot;\n'],
      [' ','  '], ['kw','private final'], [' ',' List<Counterparty> counterparty;'], ['comment',' // size = 2'],
      [' ','\n  '], ['kw','private final'], [' ',' List<AncillaryParty> ancillaryParty;\n'],
      [' ','  '], ['kw','private final'], [' '],['type','NotionalAdjustment'], [' ',' adjustment;\n'],
      ['op','}'],
    ],
    Py: [
      ['comment','# Generated by @rune-langium/codegen — DO NOT EDIT'],
      ['kw','from'], [' ',' pydantic '], ['kw','import'], [' ',' BaseModel, Field\n'],
      ['kw','from'], [' ',' typing '], ['kw','import'], [' ',' List, Optional\n\n'],
      ['kw','class'], [' ',' '], ['type','TradableProduct'], ['op','('], ['id','BaseModel'], ['op','):\n'],
      ['comment','    """A product that may be traded between counterparties."""\n'],
      [' ','    product'], ['op',': '], ['type','NonTransferableProduct'], [' ','\n'],
      [' ','    tradeLot'], ['op',': '], ['type','List[TradeLot]'], [' ',' = Field(min_length='], ['num','1'], ['op',')\n'],
      [' ','    counterparty'], ['op',': '], ['type','List[Counterparty]'], [' ',' = Field(min_length='], ['num','2'], ['op',', max_length='], ['num','2'], ['op',')\n'],
      [' ','    ancillaryParty'], ['op',': '], ['type','List[AncillaryParty]'], [' ',' = []\n'],
      [' ','    adjustment'], ['op',': '], ['type','Optional[NotionalAdjustment]'], [' ',' = '], ['kw','None'], [' ','\n'],
    ],
    JSON: [
      ['op','{\n'],
      [' ','  '], ['meta','"$id"'], ['op',': '], ['str','"cdm/product/template/TradableProduct"'], ['op',',\n'],
      [' ','  '], ['meta','"type"'], ['op',': '], ['str','"object"'], ['op',',\n'],
      [' ','  '], ['meta','"properties"'], ['op',': {\n'],
      [' ','    '], ['meta','"product"'], ['op',':       { '], ['meta','"$ref"'], ['op',': '], ['str','"#/$defs/NonTransferableProduct"'], ['op',' },\n'],
      [' ','    '], ['meta','"tradeLot"'], ['op',':      { '], ['meta','"type"'], ['op',': '], ['str','"array"'], ['op',', '], ['meta','"minItems"'], ['op',': '], ['num','1'], ['op',' },\n'],
      [' ','    '], ['meta','"counterparty"'], ['op',': { '], ['meta','"type"'], ['op',': '], ['str','"array"'], ['op',', '], ['meta','"minItems"'], ['op',': '], ['num','2'], ['op',', '], ['meta','"maxItems"'], ['op',': '], ['num','2'], ['op',' }\n'],
      [' ','  },\n'],
      [' ','  '], ['meta','"required"'], ['op',': ['], ['str','"product"'], ['op',', '], ['str','"tradeLot"'], ['op',', '], ['str','"counterparty"'], ['op',']\n'],
      ['op','}'],
    ],
  };
  const FILE = {
    TS: 'TradableProduct.ts', Java: 'TradableProduct.java',
    Py: 'tradable_product.py', JSON: 'TradableProduct.schema.json',
  }[target];
  const tokens = SNIPPETS[target];

  // Group tokens into lines based on \n in their text
  const lines = [];
  let cur = [];
  for (const [k, txt] of tokens) {
    const parts = String(txt).split('\n');
    parts.forEach((p, i) => {
      if (p) cur.push([k, p]);
      if (i < parts.length - 1) { lines.push(cur); cur = []; }
    });
  }
  if (cur.length) lines.push(cur);

  return (
    <div className="rs-pane-body rs-pane-source">
      <div className="rs-source-meta">
        <span className="rs-pill rs-pill-soft">{target}</span>
        <span className="rs-source-path">{FILE}</span>
        <span className="rs-source-spacer"/>
        <span className="rs-source-stat">generated · 92ms · {lines.length} lines</span>
      </div>
      <div className="rs-code">
        {lines.map((tks, i) => (
          <div key={i} className="rs-code-line">
            <span className="rs-code-gutter">{i+1}</span>
            <span className="rs-code-text">
              {tks.map(([k,txt],j) => k===' ' ? txt : <span key={j} className={`tok-${k}`}>{txt}</span>)}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

window.Workspace = Workspace;
window.CodeView = CodeView;
window.SourceView = SourceView;
